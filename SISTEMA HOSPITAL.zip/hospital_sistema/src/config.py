import json
from pymongo import MongoClient


client = MongoClient("mongodb+srv://informatica1:informatica1@cluster0.evpxu.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
db = client["general_hospital"]


ADMIN_USUARIO = "admin_hospital"
ADMIN_CONTRASEÑA = "test123"

class HospitalDB:
    def __init__(self):
        self.is_autentificado = False
    
    def login(self):
        usuario = input("Usuario: ")
        contraseña = input("Contraseña: ")
        
        if usuario == ADMIN_USUARIO and contraseña == ADMIN_CONTRASEÑA:
            print("Acceso concedido")
            self.is_autentificado = True
            return True
        else:
            print("Usuario o contraseña incorrectos")
            return False

    def obtener_datos(self, coleccion):
        if not self.is_autentificado:
            print("Debe iniciar sesión primero")
            return
        try:
            datos = db[coleccion].find()
            for dato in datos:
                print(dato)
        except Exception as e:
            print(f"Error al obtener datos: {e}")

    def agregar_dato(self, coleccion, dato):
        if not self.is_autentificado:
            print("Debe iniciar sesión primero")
            return
        try:
            db[coleccion].insert_one(dato)
            print("Dato agregado exitosamente")
        except Exception as e:
            print(f"Error al agregar dato: {e}")

    def eliminar_dato(self, coleccion, query):
        if not self.is_autentificado:
            print("Debe iniciar sesión primero")
            return
        try:
            resultado = db[coleccion].delete_one(query)
            if resultado.deleted_count > 0:
                print("Dato eliminado exitosamente")
            else:
                print("No se encontró el dato para eliminar")
        except Exception as e:
            print(f"Error al eliminar dato: {e}")

    def menu(self):
        while True:
            if not self.is_autentificado:
                print("SISTEMA HOSPITAL <3")
                print("1. Iniciar sesión")
                print("2. Salir")
                opcion = input("Seleccione una opción: ")
                
                if opcion == "1":
                    self.login()
                elif opcion == "2":
                    print("¡Hasta luego!")
                    break
                else:
                    print("Opción no válida")
            else:
                print("MENÚ PRINCIPAL")
                print("1. Gestión de Médicos")
                print("2. Gestión de Pacientes")
                print("3. Gestión de Historias Clínicas")
                print("4. Gestión de Citas")
                print("5. Cerrar sesión")
                print("6. Salir")
                
                opcion = input("Seleccione una opción: ")
                
                if opcion == "1":
                    self.menu_medicos()
                elif opcion == "2":
                    self.menu_pacientes()
                elif opcion == "3":
                    self.menu_historias()
                elif opcion == "4":
                    self.menu_citas()
                elif opcion == "5":
                    self.is_autentificado= False
                    print("Sesión cerrada")
                elif opcion == "6":
                    print("¡Hasta luego!")
                    break
                else:
                    print("Opción no válida")

    def menu_medicos(self):
        while True:
            print("GESTIÓN DE MÉDICOS")
            print("1. Ver médicos")
            print("2. Agregar médico")
            print("3. Eliminar médico")
            print("4. Volver al menú principal")
            
            opcion = input("Seleccione una opción: ")
            
            if opcion == "1":
                self.obtener_datos("medicos")
            elif opcion == "2":
                id_medico = input("ID del médico: ")
                nombre = input("Nombre del médico: ")
                especialidad = input("Especialidad: ")
                telefono= input("Telefono: ")
                gmail= input("Correo: ")


                medico = {
                    "id_medico": id_medico,
                    "nombre": nombre,
                    "especialidad": especialidad,
                    "tefelono": telefono,
                     "gmail":gmail }
                self.agregar_dato("medicos", medico)
            elif opcion == "3":
                id_medico = input("ID del médico a eliminar: ")
                self.eliminar_dato("medicos", {"id_medico": id_medico})
            elif opcion == "4":
                break
            else:
                print("Opción no válida")

    def menu_pacientes(self):
        while True:
            print("GESTIÓN DE PACIENTES")
            print("1. Ver pacientes")
            print("2. Agregar paciente")
            print("3. Eliminar paciente")
            print("4. Volver al menú principal")
            
            opcion = input("Seleccione una opción: ")
            
            if opcion == "1":
                self.obtener_datos("pacientes")
            elif opcion == "2":
                id_paciente = input("ID del paciente: ")
                nombre = input("Nombre del paciente: ")
                apellido=input("Apellido del paciente: ")
                nacimiento=input("Fecha de nacimiento DD/MM/AAAA: ")
                genero=input("Genero M/F: ")
                direccion=input("Direccion: ")
                telefono=input("teléfono:")

                edad = input("Edad del paciente: ")

                paciente = {
                    "id_paciente": id_paciente,
                    "nombre": nombre,
                    "edad": edad,
                     "apellido": apellido,
                      "nacimiento": nacimiento,
                       "genero": genero,
                        "direccion": direccion,
                         "telefono": telefono





                }
                self.agregar_dato("pacientes", paciente)
            elif opcion == "3":
                id_paciente = input("ID del paciente a eliminar: ")
                self.eliminar_dato("pacientes", {"id_paciente": id_paciente})
            elif opcion == "4":
                break
            else:
                print("Opción no válida")

    def menu_historias(self):
        while True:
            print("GESTIÓN DE HISTORIAS CLÍNICAS")
            print("1. Ver historias clínicas")
            print("2. Agregar historia clínica")
            print("3. Eliminar historia clínica")
            print("4. Volver al menú principal")
            
            opcion = input("Seleccione una opción: ")
            
            if opcion == "1":
                self.obtener_datos("historias")
            elif opcion == "2":
                id_paciente = input("ID del paciente: ")
                fecha = input("Fecha de visita (DD/MM/YYYY): ")
                diagnostico = input("Diagnóstico: ")
                tratamiento=input("Tratamiento: ")
                notas=input("Notas: ")


                historia = {
                    "id_paciente": id_paciente,
                    "fecha": fecha,
                    "diagnostico": diagnostico,
                     "tratamiento": tratamiento,
                      "notas": notas


                }
                self.agregar_dato("historias", historia)
            elif opcion == "3":
                id_paciente = input("ID del paciente cuya historia desea eliminar: ")
                self.eliminar_dato("historias", {"id_paciente": id_paciente})
            elif opcion == "4":
                break
            else:
                print("Opción no válida")

    def menu_citas(self):
        while True:
            print("GESTIÓN DE CITAS ")
            print("1. Ver citas")
            print("2. Agregar cita")
            print("3. Eliminar cita")
            print("4. Volver al menú principal")
            
            opcion = input("Seleccione una opción: ")
            
            if opcion == "1":
                self.obtener_datos("citas")
            elif opcion == "2":
                id_paciente = input("ID del paciente: ")
                id_medico = input("ID del médico: ")
                fecha = input("Fecha de la cita (DD/MM/YYYY): ")
                hora = input("Hora de la cita (HH:MM): ")
                razon=input("Razon de la cita: ")

                cita = {
                    "id_paciente": id_paciente,
                    "id_medico": id_medico,
                    "fecha": fecha,
                    "hora": hora,
                     "razon": razon
                }
                self.agregar_dato("citas", cita)
            elif opcion == "3":
                id_paciente = input("ID del paciente cuya cita desea eliminar: ")
                self.eliminar_dato("citas", {"id_paciente": id_paciente})
            elif opcion == "4":
                break
            else:
                print("Opción no válida")

if __name__ == "__main__":
    sistema = HospitalDB()
    sistema.menu()